using AutoMapper;
using BankLending_BAL.DTO;
using BankLending_BAL.Mapper;
using BankLending_BAL.Repository;
using BankLending_BAL.Services;
using Moq;
namespace UnitTesting

{

    [TestFixture]
    public class Tests
    {
        private Mock<IBankLendingRepository> _mockRepository;
        private BankLendingService _bankLendingService;
        private IMapper _mapper;
        [SetUp]
        public void Setup()
        {
            if (_mapper == null)
            {
                var mappingConfig = new MapperConfiguration(mc =>
                {
                    mc.AddProfile(new BankLendingMapper());
                });
                IMapper mapper = mappingConfig.CreateMapper();
                _mapper = mapper;
            }
            _mockRepository = new Mock<IBankLendingRepository>();
            _bankLendingService = new BankLendingService(_mockRepository.Object);
        }
        //get values 1
        [Test]
        public async Task GetLoanInformation_Should_Return_Loan()
        {
            // Arrange: Create a sample loan ID
            int loanId = 1;

            // Arrange: Mock the repository's GetLoanById method
            var expectedLoan = new LoanMasterDTO { typeofloan = "loan", interestRate = 10, dateOfCreation = new DateTime(2024, 4, 19) };
            _mockRepository.Setup(repo => repo.GetLoanById(loanId)).ReturnsAsync(expectedLoan);

            // Act: Call the service method
            var result = await _bankLendingService.GetLoanInformation(loanId);
            _mockRepository.Verify(m => m.GetLoanById(1), Times.Once);

            // Assert: Verify that the result matches the expected loan
          
            Assert.That(result, Is.Not.Null);
            Assert.That(result,Is.InstanceOf<LoanMasterDTO>());

            LoanMasterDTO tempDTO = result as LoanMasterDTO;

            Assert.That(tempDTO.typeofloan, Is.EqualTo("loan"));
        }
        //2
        [Test]
        public async Task GetLoanInformation_Should_Return_Null()
        {
            // Arrange
            int loanId = 100;

            var expectedLoan = new LoanMasterDTO { typeofloan = "Loan", interestRate = 11, dateOfCreation = new DateTime(2024, 4, 16) };
            _mockRepository.Setup(repo => repo.GetLoanById(loanId)).ReturnsAsync((LoanMasterDTO?)null);

            // Act
            var result = await _bankLendingService.GetLoanInformation(loanId);

            //Assert
            Assert.That(result, Is.Null);
            //Assert.That(result, Is.InstanceOf<LoanMasterDTO>());
            
        }
        //3
        [Test]
        public async Task GetLoanInformation_ThrowsException()
        {
            _mockRepository.Setup(m => m.GetLoanById(1)).ThrowsAsync(new Exception());

            Assert.ThrowsAsync<Exception>(
                async () =>
                {
                    var result = await _bankLendingService.GetLoanInformation(1);
                });

        }
        //get all 4
        [Test]
        public async Task GetLoanMasters_Should_Return_Loan()
        {
            
            var expectedLoan = new List<LoanMasterDTO> 
            { new LoanMasterDTO { typeofloan = "loan", interestRate = 1, dateOfCreation = new DateTime(2024, 4, 18) },
                 new LoanMasterDTO { typeofloan = "Car Loan", interestRate = 10, dateOfCreation = new DateTime(2024, 4, 16) }
            };
            _mockRepository.Setup(repo => repo.GetAllLoan()).ReturnsAsync(expectedLoan);

            
            var result = await _bankLendingService.GetLoanMasters();
            _mockRepository.Verify(m => m.GetAllLoan(), Times.Once);

            
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.All.InstanceOf<LoanMasterDTO>());

        }
        //5
        [Test]
        public async Task GetLoanMasters_Should_Return_Null()
        {

            var expectedLoan = new List<LoanMasterDTO>();
            _mockRepository.Setup(repo => repo.GetAllLoan()).ReturnsAsync(expectedLoan);


            var result = await _bankLendingService.GetLoanMasters();
            _mockRepository.Verify(m => m.GetAllLoan(), Times.Once);


            Assert.That(result, Is.Empty);
          

        }
        //add  6

        [Test]
        public async Task addloan_should_return_success()
        {
            var loan = new LoanMasterDTO { typeofloan = "test loan", interestRate = 11 };

            _mockRepository.Setup(m => m.AddLoan(loan)).ReturnsAsync(1);

            var result = await _bankLendingService.AddLoanInformation(loan);
            Assert.NotNull(result);
            Assert.That(result, Is.EqualTo(1));
        }
        //7
        [Test]
        public async Task addloan_should_return_Failed()
        {
            var loan = new LoanMasterDTO { typeofloan = "test loan", interestRate = 11 };
            _mockRepository.Setup(m => m.AddLoan(loan)).ReturnsAsync((int?)null);
            var result = await _bankLendingService.AddLoanInformation(loan);
            Assert.Null(result);
        }
        //8
        //update
        [Test]
        public async Task update_loan_should_return_success()
        {
            var loan = new LoanMasterDTO { loanId = 5, typeofloan = "updated loan", interestRate = 12 };

            _mockRepository.Setup(m => m.UpdateLoan(loan.loanId, loan)).ReturnsAsync(true);

            var result = await _bankLendingService.UpdateLoanInformation(loan.loanId, loan);
            Assert.NotNull(result);
            Assert.True(result);
        }
        //9
        [Test]
        public async Task update_loan_should_return_Failed()
        {
            var loan = new LoanMasterDTO { loanId = 7, typeofloan = "updated loan", interestRate = 12 };
            _mockRepository.Setup(m => m.UpdateLoan(loan.loanId, loan)).ReturnsAsync(false);

            var result = await _bankLendingService.UpdateLoanInformation(loan.loanId, loan);

            Assert.False(result);
        }
        //10
        //calculate EMI

        [Test]
        public async Task CalculateInstallment_Should_Return_EMI()
        {
            // Arrange: Create a sample LoanApp_Id
            int loanAppId = 2;

            // Arrange: Mock the repository's EMICalculation method
            var myLoanDTO = new LoanAppMasterDTO { loanAmount = 10000, rateOfInterest = 10, noOfMonths = 12 };
            _mockRepository.Setup(repo => repo.EMICalculation(loanAppId)).ReturnsAsync(myLoanDTO);

            // Act: Call the service method
            var result = await _bankLendingService.CalculateInstallment(loanAppId);

            // Assert: Verify that the result is not null and is an integer
            Assert.NotNull(result);
            Assert.IsInstanceOf<int>(result);
        }

        //11
        [Test]
        public async Task CalculateInstallment_Should_Return_Null()
        {
            
            int loanAppId = 42;

            _mockRepository.Setup(repo => repo.EMICalculation(loanAppId)).ReturnsAsync((LoanAppMasterDTO?)null);

            var result = await _bankLendingService.CalculateInstallment(loanAppId);

            Assert.Null(result);
        }

        //12
        //installment calculation
        [Test]
        public async Task GetReducedPaymentInformation_Should_Return_Success()
        {
           
            
            var expectedLoan = new LoanAppMasterDTO
            {
                loanAppId = 2,
                loanAmount = 100000,
                rateOfInterest = 10,
                noOfMonths = 12,
                applicationDate = new DateTime(2024, 04, 16)
            };

            int loanAppId = 2;
            var myLoanDTO = new LoanAppMasterDTO { loanAmount = 100000, rateOfInterest = 10, noOfMonths = 12 };
            

            _mockRepository.Setup(repo => repo.GetReducedPayment(loanAppId)).ReturnsAsync(expectedLoan);
            _mockRepository.Setup(repo => repo.EMICalculation(loanAppId)).ReturnsAsync(myLoanDTO);

            _mockRepository.Setup(repo => repo.AddGetReducedPayment(It.IsAny<LoanAppDetailMasterDTO>())).ReturnsAsync(1);

           
            var result = await _bankLendingService.GetReducedPaymentInformation(loanAppId);

            Assert.True(result);

        }
        //13
        [Test]
        public async Task GetReducedPaymentInformation_Should_Return_Failure()
        {
            // Arrange: Create a sample id
            int loanId = 42;

            // Arrange: Mock the repository's GetReducedPayment method to return null
            _mockRepository.Setup(repo => repo.GetReducedPayment(loanId)).ReturnsAsync((LoanAppMasterDTO?)null);

            // Act: Call the service method
            var result = await _bankLendingService.GetReducedPaymentInformation(loanId);

            // Assert: Verify that the result is false
            Assert.False(result);
        }

        //14
        //printing
        [Test]
        public async Task ReducedPayemtList_Should_Return_Success()
        {
            // Arrange: Create a sample loanApp_id
            int loanAppId = 42;

            // Arrange: Mock the repository's GenerateRPayment method
            var expectedLoanDetails = new List<LoanAppDetailMasterDTO> {
        
             new LoanAppDetailMasterDTO { loanAppId=2,monthNo=1,installment=8792,interestRate=833,pOutStandingBeginOfMon=100000,pRepayment=7959,prOutStandingEndOfmon=92041,lastDateofinstallPay= new DateTime(2024,05,16)},
              new LoanAppDetailMasterDTO { loanAppId=2,monthNo=1,installment=8792,interestRate=767,pOutStandingBeginOfMon=92041,pRepayment=8025,prOutStandingEndOfmon=84016,lastDateofinstallPay= new DateTime(2024,06,16)}

             };
            _mockRepository.Setup(repo => repo.GenerateRPayment(loanAppId)).ReturnsAsync(expectedLoanDetails);

            // Act: Call the service method
            var result = await _bankLendingService.ReducedPayemtList(loanAppId);

            // Assert: Verify that the result is not null and contains valid loan details
            
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.All.InstanceOf<LoanAppDetailMasterDTO>());
            
        }
        //15
        [Test]
        public async Task ReducedPayemtList_Should_Return_Failure()
        {
            // Arrange: Create a sample loanApp_id
            int loanAppId = 20;

            // Arrange: Mock the repository's GenerateRPayment method to return an empty list (or null)
            _mockRepository.Setup(repo => repo.GenerateRPayment(loanAppId)).ReturnsAsync(new List<LoanAppDetailMasterDTO>());

            // Act: Call the service method
            var result = await _bankLendingService.ReducedPayemtList(loanAppId);

            // Assert: Verify that the result is an empty list (or null)
            
            Assert.That(result, Is.Empty);
            // Add more specific assertions based on your actual data
        }


    }
}