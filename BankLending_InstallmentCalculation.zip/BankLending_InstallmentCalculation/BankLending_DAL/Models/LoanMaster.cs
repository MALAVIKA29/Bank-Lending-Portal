﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLending_DAL.Models
{
    public class LoanMaster
    {
        [Key]
        public int loanId { get; set; }
        public string typeofloan { get; set; }
        public int interestRate { get; set; }
        public DateTime dateOfCreation { get; set; }
    }
}
