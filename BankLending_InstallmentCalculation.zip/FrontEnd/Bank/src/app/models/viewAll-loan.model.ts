export interface viewLoan{
    loanId:number;
    typeofloan:string;
    interestRate:number;
    dateOfCreation:Date;
}