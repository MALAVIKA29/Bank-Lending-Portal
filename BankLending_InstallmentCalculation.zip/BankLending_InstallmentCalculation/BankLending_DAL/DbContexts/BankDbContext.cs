﻿using BankLending_DAL.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLending_DAL.DbContexts
{
    public class BankDbContext : DbContext
    {
        public BankDbContext() { }
        public BankDbContext(DbContextOptions<BankDbContext> options) : base(options) { }



        public DbSet<LoanMaster> LoanMasters { get; set; }
        public DbSet<LoanAppMaster> LoanAppMasters { get; set; }
        public DbSet<LoanAppDetailMaster> LoanAppDetailMasters { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<LoanMaster>()
                .Property(l => l.dateOfCreation)
                .HasColumnType("Date")
                .HasDefaultValueSql("GETDATE()");

            modelBuilder.Entity<LoanMaster>()
                .Property(l => l.typeofloan)
                .HasColumnType("varchar(255)");

            modelBuilder.Entity<LoanMaster>()
                .HasIndex(l => new { l.loanId, l.typeofloan, l.dateOfCreation });


            modelBuilder.Entity<LoanAppDetailMaster>()
               .Property(l => l.lastDateofinstallPay)
               .HasColumnType("Date");

            modelBuilder.Entity<LoanAppMaster>()
              .Property(l => l.applicationDate)
              .HasColumnType("Date");

            modelBuilder.Entity<LoanAppMaster>()
                 .HasOne(typeof(LoanMaster))
                 .WithMany()
                 .IsRequired()
                 .HasForeignKey("loanId");

            modelBuilder.Entity<LoanAppDetailMaster>()
                .HasOne(typeof(LoanAppMaster))
                 .WithMany()
                 .IsRequired()
                 .HasForeignKey("loanAppId");
        }
    }
}
