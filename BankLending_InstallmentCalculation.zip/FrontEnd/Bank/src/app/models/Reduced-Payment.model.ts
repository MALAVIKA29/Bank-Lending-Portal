export interface ReducedPayment{
    Id:number;
    loanAppId:number;
    monthNo:number;
    installment:number;
    interestRate:number;
    pOutStandingBeginOfMon:number;
    pRepayment:number;
    prOutStandingEndOfmon:number;
    lastDateofinstallPay:Date;
}

