﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLending_DAL.Models
{
    public class LoanAppDetailMaster
    {
        [Key]
        public int Id { get; set; }
        public int loanAppId { get; set; }
        public int monthNo { get; set; }
        public int installment { get; set; }
        public int interestRate { get; set; }
        public int pOutStandingBeginOfMon { get; set; }
        public int pRepayment { get; set; }
        public int prOutStandingEndOfmon { get; set; }
        public DateTime lastDateofinstallPay { get; set; }
    }
}
