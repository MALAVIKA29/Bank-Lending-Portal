using BankLending_BAL.Mapper;
using BankLending_BAL.Repository;
using BankLending_BAL.Services;
using BankLending_DAL.DbContexts;
using Microsoft.EntityFrameworkCore;

public class Program
{
    private static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // Add services to the container.
        builder.Services.AddDbContext<BankDbContext>(o => o.UseSqlServer(builder.Configuration.GetConnectionString("BankLendingDBCon")));
      
        builder.Services.AddScoped<IBankLendingService, BankLendingService>();
        builder.Services.AddScoped<IBankLendingRepository, BankLendingRepository>();

        builder.Services.AddControllers();
        // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerGen();

        builder.Services.AddAutoMapper(typeof(BankLendingMapper));
       
        var app = builder.Build();//instance
       

        // Configure the HTTP request pipeline.
        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI();
        }

        app.UseHttpsRedirection();
        app.UseCors(options =>
        {
            options.AllowAnyHeader();
            options.AllowAnyOrigin();
            options.AllowAnyMethod();
        });

        app.UseAuthorization();

        app.MapControllers();

        app.Run();
    }
}