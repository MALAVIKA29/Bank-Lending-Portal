﻿using BankLending_BAL.DTO;
using BankLending_BAL.Repository;
using BankLending_BAL.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Transactions;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BankLending_InstallmentCalculation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BankLendingController : ControllerBase
    {

        private readonly IBankLendingRepository _BankRepository;
        private readonly IBankLendingService _BankService;

        public BankLendingController(IBankLendingRepository BankLendingRepository, IBankLendingService BankService)
        {
            _BankRepository = BankLendingRepository;
            _BankService = BankService;
        }


        //1
        // POST api/<BankLendingController>
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] LoanMasterDTO loan)
        {
            try
            {
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    var loanId = await _BankService.AddLoanInformation(loan);

                    if (loanId == 0)
                    {
                        return BadRequest("Failed to add loan information");
                    }
                    scope.Complete();
                    return CreatedAtAction(nameof(Get), new { Loan_id = loanId }, loan);
                }


            }
            catch (Exception ex)
            {

                return StatusCode(500, $"An error occurred: {ex.Message}");
            }
        }
        //2
        // GET api/<BankLendingController>/5
        [HttpGet("{Loan_id}", Name = "Get")]
        public async Task<IActionResult> Get(int Loan_id)
        {
            try
            {
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    var loan = await _BankService.GetLoanInformation(Loan_id);
                    if (loan == null)
                    {
                        return NotFound();
                    }
                    scope.Complete();
                    return Ok(loan);

                }
            }
            catch (Exception ex)
            {

                return StatusCode(500, $"An error occurred: {ex.Message}");
            }
        }
        //3
        [HttpGet]
        public async Task<IActionResult> GetAllLoan()
        {
            try
            {
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    var Loan = await _BankService.GetLoanMasters();
                    scope.Complete();
                    return Ok(Loan);

                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred: {ex.Message}");
            }

        }
        //4
        [HttpPut("{Loan_id}")]
        public async Task<IActionResult> Put(int Loan_id, [FromBody] LoanMasterDTO loan)
        {
            try
            {
                if (loan != null)
                {
                    using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                    {
                        var success = await _BankService.UpdateLoanInformation(Loan_id, loan);
                        if (success)
                        {
                            scope.Complete();
                            return Ok();
                        }
                        else
                        {
                            return BadRequest("Failed to update loan information");
                        }

                    }
                }
                else
                {
                    return BadRequest("Invalid loan data");

                }


            }
            catch (Exception ex)
            {

                return StatusCode(500, $"An error occurred: {ex.Message}");
            }
        }
        //5
        [HttpGet("emi/{LoanApp_Id}", Name = "GetEMI")]
        public async Task<IActionResult> GetEMI(int LoanApp_Id)
        {
            try
            {
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    var loan = await _BankService.CalculateInstallment(LoanApp_Id);
                    if (loan == null)
                    {

                        return NotFound("value is null");
                    }
                    scope.Complete();
                    return Ok(loan);

                }
            }
            catch (Exception ex)
            {

                return StatusCode(500, $"An error occurred: {ex.Message}");
            }
        }
        //6
        //GetReducedPaymentInformation

        [HttpPost("id/{id}")]
        public async Task<IActionResult> AddReducedPayment(int id)
        {
            try
            {
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    var loaninformation = await _BankService.GetReducedPaymentInformation(id);
                    scope.Complete();
                    return Ok(loaninformation);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred: {ex.Message}");
            }
        }

        //7 
        // GET api/<BankLendingController>/5
        [HttpGet("GeneratePayment/{LoanApp_id}", Name = "GenerateReducedPayment")]
        public async Task<IActionResult> GenerateReducedPayment(int LoanApp_id)
        {
            try
            {
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    var loan = await _BankService.ReducedPayemtList(LoanApp_id);
                    if (loan == null)
                    {
                        return NotFound();
                    }
                    scope.Complete();
                    return Ok(loan);

                }
            }
            catch (Exception ex)
            {

                return StatusCode(500, $"An error occurred: {ex.Message}");
            }
        }
    }
}
