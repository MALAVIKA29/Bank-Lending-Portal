import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './Home/home/home.component';
import { AddLoanComponent } from './Loan/add-loan/add-loan.component';
import { UpdateLoanComponent } from './Loan/update-loan/update-loan.component';
import { ViewAllLoanComponent } from './Loan/view-all-loan/view-all-loan.component';
import { EditLoanComponent } from './Loan/edit-Loan/edit-loan.component';
import { LoanByIdComponent } from './Search/loan-by-id/loan-by-id.component';
import { ReducedPaymentComponent } from './Search/reduced-payment/reduced-payment.component';
import { CalcEmiComponent } from './Installment/calc-emi/calc-emi.component';
import { GenerateReducedPaymentComponent } from './Installment/generate-reduced-payment/generate-reduced-payment.component';


const routes: Routes = [
  { path:'home', component:HomeComponent},
  { path:'addloan', component:AddLoanComponent},
  { path:'allLoan',component:ViewAllLoanComponent},
  { path:'updateLoan/:loanId',component:UpdateLoanComponent},
  { path:'editLoan',component:EditLoanComponent},
  { path:'searchById',component:LoanByIdComponent},
  { path:'reducedPaymentById',component:ReducedPaymentComponent},
  { path:'calcEmi',component:CalcEmiComponent},
  { path:'generate',component:GenerateReducedPaymentComponent},
  { path:'',redirectTo:'/home',pathMatch:'full'}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
