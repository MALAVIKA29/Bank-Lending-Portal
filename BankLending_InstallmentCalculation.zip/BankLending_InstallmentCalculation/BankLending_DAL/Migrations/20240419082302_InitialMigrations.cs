﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BankLending_DAL.Migrations
{
    /// <inheritdoc />
    public partial class InitialMigrations : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "LoanMasters",
                columns: table => new
                {
                    loanId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    typeofloan = table.Column<string>(type: "varchar(255)", nullable: true),
                    interestRate = table.Column<int>(type: "int", nullable: false),
                    dateOfCreation = table.Column<DateTime>(type: "Date", nullable: false, defaultValueSql: "GETDATE()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LoanMasters", x => x.loanId);
                });

            migrationBuilder.CreateTable(
                name: "LoanAppMasters",
                columns: table => new
                {
                    loanAppId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    loanId = table.Column<int>(type: "int", nullable: false),
                    loanAmount = table.Column<double>(type: "float", nullable: false),
                    noOfMonths = table.Column<int>(type: "int", nullable: false),
                    rateOfInterest = table.Column<int>(type: "int", nullable: false),
                    applicationDate = table.Column<DateTime>(type: "Date", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LoanAppMasters", x => x.loanAppId);
                    table.ForeignKey(
                        name: "FK_LoanAppMasters_LoanMasters_loanId",
                        column: x => x.loanId,
                        principalTable: "LoanMasters",
                        principalColumn: "loanId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "LoanAppDetailMasters",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    loanAppId = table.Column<int>(type: "int", nullable: false),
                    monthNo = table.Column<int>(type: "int", nullable: false),
                    installment = table.Column<int>(type: "int", nullable: false),
                    interestRate = table.Column<int>(type: "int", nullable: false),
                    pOutStandingBeginOfMon = table.Column<int>(type: "int", nullable: false),
                    pRepayment = table.Column<int>(type: "int", nullable: false),
                    prOutStandingEndOfmon = table.Column<int>(type: "int", nullable: false),
                    lastDateofinstallPay = table.Column<DateTime>(type: "Date", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LoanAppDetailMasters", x => x.Id);
                    table.ForeignKey(
                        name: "FK_LoanAppDetailMasters_LoanAppMasters_loanAppId",
                        column: x => x.loanAppId,
                        principalTable: "LoanAppMasters",
                        principalColumn: "loanAppId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_LoanAppDetailMasters_loanAppId",
                table: "LoanAppDetailMasters",
                column: "loanAppId");

            migrationBuilder.CreateIndex(
                name: "IX_LoanAppMasters_loanId",
                table: "LoanAppMasters",
                column: "loanId");

            migrationBuilder.CreateIndex(
                name: "IX_LoanMasters_loanId_typeofloan_dateOfCreation",
                table: "LoanMasters",
                columns: new[] { "loanId", "typeofloan", "dateOfCreation" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "LoanAppDetailMasters");

            migrationBuilder.DropTable(
                name: "LoanAppMasters");

            migrationBuilder.DropTable(
                name: "LoanMasters");
        }
    }
}
