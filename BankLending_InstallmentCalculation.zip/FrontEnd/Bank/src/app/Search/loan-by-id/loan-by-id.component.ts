import { Component, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { viewLoan } from '../../models/viewAll-loan.model';
import { ActivatedRoute, Router } from '@angular/router';
import { LoanServiceService } from '../../Services/loan-service.service';

@Component({
  selector: 'app-loan-by-id',
  templateUrl: './loan-by-id.component.html',
  styleUrl: './loan-by-id.component.css'
})
export class LoanByIdComponent implements OnDestroy{
  LoanId:number =null;
  loanSubscription?:Subscription;
   a:number=0;
  loan?:viewLoan;
  constructor( private router:Router,
    private route:ActivatedRoute,
    private LoanService:LoanServiceService
   ){ }
   onSubmit()
   {
    this.loanSubscription= this.LoanService.getLoanByID(this.LoanId)
     .subscribe(
      (loan)=>{
        this.loan=loan;
        this.a=1;
        console.log(loan);
        console.log(this.a);
      },
      error=>{
        this.a=2;
      }
    );
   }
   onChange()
   {
    this.a=0;
   }
   ngOnDestroy(): void {
      this.loanSubscription?.unsubscribe();
     }
  
}
