﻿using AutoMapper;
using BankLending_BAL.DTO;
using BankLending_BAL.Repository;
using BankLending_DAL.DbContexts;
using BankLending_DAL.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLending_BAL.Services
{
    public class BankLendingService : IBankLendingService
    {

        private readonly IBankLendingRepository _bankLendingRepository;
        

        public BankLendingService(IBankLendingRepository bankLendingRepository/*, BankDbContext dbcontext, IMapper mapper*/)
        {
            _bankLendingRepository = bankLendingRepository ?? throw new ArgumentNullException(nameof(bankLendingRepository));
            
        }
        //AddLoadInformation
        public async Task<int?> AddLoanInformation(LoanMasterDTO loan)
        {
            var success = await _bankLendingRepository.AddLoan(loan);
            if(success== null)
            {
                return null;
            }
            return success;
        }
        //GetLoanInformation
        public async Task<object> GetLoanInformation(int loan_id)
        {
            var loan = await _bankLendingRepository.GetLoanById(loan_id);
            return loan;
        }

        public async Task<List<LoanMasterDTO>> GetLoanMasters()
        {
            var myloans = await _bankLendingRepository.GetAllLoan();
            return myloans;
        }

        public async Task<bool> UpdateLoanInformation(int id, LoanMasterDTO loan)
        {
            var success = await _bankLendingRepository.UpdateLoan(id, loan);
            return success;
        }

        public async Task<int?> CalculateInstallment(int LoanApp_Id)
        {
            try
            {
                var myLoanDTO = await _bankLendingRepository.EMICalculation(LoanApp_Id);
                if (myLoanDTO == null)
                {
                    return null;
                }
                double principalOutstanding = myLoanDTO.loanAmount;
                double annualInterestRate = myLoanDTO.rateOfInterest;
                int noOfMonths = myLoanDTO.noOfMonths;

                double monthlyInterestRate = annualInterestRate / 12 / 100;

                // Calculate EMI 
                double emiNumerator = principalOutstanding * monthlyInterestRate * Math.Pow(1 + monthlyInterestRate, noOfMonths);
                double emiDenominator = Math.Pow(1 + monthlyInterestRate, noOfMonths) - 1;
                double emi = emiNumerator / emiDenominator;

                return (int)Math.Round(emi);
            } catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<bool> GetReducedPaymentInformation(int id)
        {
            var myLoanDTO = await _bankLendingRepository.GetReducedPayment(id);
            if(myLoanDTO == null)
            {
                return false;
            }
            double principalOutstanding = myLoanDTO.loanAmount;
            double annualInterestRate = myLoanDTO.rateOfInterest;
            int noOfMonths = myLoanDTO.noOfMonths;
            double monthlyInterestRate = annualInterestRate / 12/100;
            DateTime LastDate = myLoanDTO.applicationDate;
            int emi = (int)await CalculateInstallment(id);
            //double emi = principalOutstanding * monthlyInterestRate * Math.Pow(1 + monthlyInterestRate, noOfMonths) / (Math.Pow(1 + monthlyInterestRate, noOfMonths) - 1);
            int c = 0;
            for (int month = 1; month <= noOfMonths; month++)
            {
                double interestComponent = monthlyInterestRate * principalOutstanding;
                double principalRepayment = emi - interestComponent;
                double principalOutstandingEnd = principalOutstanding - principalRepayment;

                DateTime firstDayOfNextMonth = new DateTime(LastDate.Year, LastDate.Month, LastDate.Day).AddMonths(1);
                DateTime LastDayOfCurrentMonth = firstDayOfNextMonth.AddDays(-1);
                LastDate = firstDayOfNextMonth;

                var loanDetailDTO = new LoanAppDetailMasterDTO
                {
                    loanAppId = myLoanDTO.loanAppId,
                    monthNo = month,
                    installment = emi,
                    interestRate = (int)Math.Round(interestComponent),
                    pOutStandingBeginOfMon = (int)Math.Round(principalOutstanding),
                    pRepayment = (int)Math.Round(principalRepayment),
                    prOutStandingEndOfmon = (c != noOfMonths-1)?(int)Math.Round(principalOutstandingEnd):0,
                    lastDateofinstallPay = LastDate
                };
                var success = await _bankLendingRepository.AddGetReducedPayment(loanDetailDTO);
                if (success == 1)
                {
                    c++;
                }
               

                // Update principal outstanding for the next month
                principalOutstanding = principalOutstandingEnd;
            }
           if(c == noOfMonths)
            {
                return true;
            }
           else
            {
                return false;
            }
            
        }
        public async Task<List<LoanAppDetailMasterDTO>> ReducedPayemtList(int loanApp_id)
        {
            var loan = await _bankLendingRepository.GenerateRPayment(loanApp_id);
            return loan;
        }


    }
        
}
