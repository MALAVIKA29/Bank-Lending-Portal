﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLending_BAL.DTO
{
    public class LoanAppMasterDTO
    {
        public int loanAppId { get; set; }


        public int loanId { get; set; }

        public double loanAmount { get; set; }
        public int noOfMonths { get; set; }
        public int rateOfInterest { get; set; }
        public DateTime applicationDate { get; set; }
    }
}
