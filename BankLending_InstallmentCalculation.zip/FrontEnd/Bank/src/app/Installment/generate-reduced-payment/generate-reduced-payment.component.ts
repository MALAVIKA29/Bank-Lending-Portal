import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { LoanServiceService } from '../../Services/loan-service.service';


@Component({
  selector: 'app-generate-reduced-payment',
  templateUrl: './generate-reduced-payment.component.html',
  styleUrl: './generate-reduced-payment.component.css'
})
export class GenerateReducedPaymentComponent {
  LoanId:number =null;
  loanSubscription?:Subscription;
  result?:boolean = null;
  // model?:dummy;
  constructor( private router:Router,
    private route:ActivatedRoute,
    private LoanService:LoanServiceService
   ){ }
   a : number = 0;
   onSubmit()
   {
    this.loanSubscription= this.LoanService.generateReducedPayment(this.LoanId)
     .subscribe(
      (loan)=>{
       this.result=loan
      if(this.result){
        this.a=1;
      }
      else{
        this.a=2;
      }
        console.log(loan);
        
      }
    );
   }
   ngOnDestroy(): void {
      this.loanSubscription?.unsubscribe();
     }
  
}
