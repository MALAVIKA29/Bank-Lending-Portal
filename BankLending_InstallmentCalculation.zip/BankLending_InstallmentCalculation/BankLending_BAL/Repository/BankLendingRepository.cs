﻿using AutoMapper;
using BankLending_BAL.DTO;
using BankLending_BAL.Services;
using BankLending_DAL.DbContexts;
using BankLending_DAL.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace BankLending_BAL.Repository
{
    public class BankLendingRepository : IBankLendingRepository
    {
        private readonly BankDbContext _dbcontext;
        private readonly IMapper _mapper;

        public BankLendingRepository()
        {
        }

        public BankLendingRepository(BankDbContext dbcontext, IMapper mapper)
        {

            _dbcontext = dbcontext ?? throw new ArgumentNullException(nameof(dbcontext));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));

        }
        //Adding the loan
        public async Task<int?> AddLoan(LoanMasterDTO loan)
        {


            if (loan == null) { return null; }
            
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    LoanMaster loanEntity = _mapper.Map<LoanMaster>(loan);
                    //Console.WriteLine(loanEntity);
                    await _dbcontext.LoanMasters.AddAsync(loanEntity);
                    await _dbcontext.SaveChangesAsync();
                    scope.Complete();
                    return loanEntity.loanId;
                }
            
           

        }

        //Get loan by ID
        public async Task<object> GetLoanById(int loan_id)
        {
            using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {

                var loan = await _dbcontext.LoanMasters.FirstOrDefaultAsync(a => a.loanId == loan_id);
                LoanMasterDTO value = _mapper.Map<LoanMasterDTO>(loan);
                scope.Complete();
                return loan;
            }
        }
        //Get all loan
        public async Task<List<LoanMasterDTO>> GetAllLoan()
        {
            using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {

                var allloan = await _dbcontext.LoanMasters.ToListAsync();
                var AllLoanDTO = _mapper.Map<List<LoanMasterDTO>>(allloan);
                scope.Complete();
                return AllLoanDTO;
            }
        }

        //Update loan
        public async Task<bool> UpdateLoan(int id, LoanMasterDTO loan)
        {
            using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                var myloan = await _dbcontext.LoanMasters.FindAsync(id);
                if (myloan == null) { return false; }
               
                {
                    
                    myloan.typeofloan = loan.typeofloan;
                    myloan.interestRate = loan.interestRate;
                    myloan.dateOfCreation = DateTime.Now;

                    _dbcontext.Entry(myloan).State = EntityState.Modified;
                    await _dbcontext.SaveChangesAsync();
                    scope.Complete();
                    return true;
                }

               

            }
        }

        public async Task<LoanAppMasterDTO> EMICalculation(int LoanApp_Id)
        {
            var myloan = await _dbcontext.LoanAppMasters.FirstOrDefaultAsync(a => a.loanAppId == LoanApp_Id);
            if (myloan == null)
            {
                return null; // Loan not found
            }

            var myLoanDTO = _mapper.Map<LoanAppMasterDTO>(myloan);
            return myLoanDTO;

        }

        public async Task<LoanAppMasterDTO> GetReducedPayment(int id)
        {
            var isthere = await _dbcontext.LoanAppDetailMasters.Where(a=>a.loanAppId == id).FirstOrDefaultAsync();
            if(isthere != null)
            {
                return null;
            }
            else
            {
                var myloan = await _dbcontext.LoanAppMasters.Where(a => a.loanAppId == id).FirstOrDefaultAsync();
                if (myloan == null) { return null; }

                var myLoanDTO = _mapper.Map<LoanAppMasterDTO>(myloan);

                return myLoanDTO;
            }
            



        }
        public async Task<int?> AddGetReducedPayment(LoanAppDetailMasterDTO loanDetailDTO)
        {
            await _dbcontext.LoanAppDetailMasters.AddAsync(_mapper.Map<LoanAppDetailMaster>(loanDetailDTO));
            await _dbcontext.SaveChangesAsync();
            return 1;
        }


        public async Task<List<LoanAppDetailMasterDTO>> GenerateRPayment(int loanApp_id)
        {
            using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {

                var loan = await _dbcontext.LoanAppDetailMasters.Where(a => a.loanAppId == loanApp_id).ToListAsync();
                var value = _mapper.Map<List<LoanAppDetailMasterDTO>>(loan);
                scope.Complete();
                return value;
            }
        }
    }
}

