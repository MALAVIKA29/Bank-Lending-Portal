import { Component, OnInit } from '@angular/core';
import { response } from 'express';
import { loan } from '../../models/Add-loan.model';
import { viewLoan } from '../../models/viewAll-loan.model';
import { LoanServiceService } from '../../Services/loan-service.service';

@Component({
  selector: 'app-view-all-loan',
  templateUrl: './view-all-loan.component.html',
  styleUrl: './view-all-loan.component.css'
})
export class ViewAllLoanComponent implements OnInit {

  Loans?: viewLoan[];
    constructor(private loanService:LoanServiceService)
    {
      
    }
    ngOnInit(): void {
      this.loanService.getAllLoan()
      .subscribe({
        next:(response)=> {
          this.Loans=response;
        }
      });
    }
}
