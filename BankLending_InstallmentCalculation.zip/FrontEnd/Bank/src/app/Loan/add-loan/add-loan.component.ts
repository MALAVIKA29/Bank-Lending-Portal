import { Component, OnDestroy } from '@angular/core';
import { response } from 'express';
import { Subscription } from 'rxjs';
import { loan } from '../../models/Add-loan.model';
import { LoanServiceService } from '../../Services/loan-service.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-add-loan',
  templateUrl: './add-loan.component.html',
  styleUrl: './add-loan.component.css'
})
export class AddLoanComponent implements OnDestroy{

  model:loan;
  // a:number=0;
  private addLoanSubscription?:Subscription;

  constructor(private router:Router, private loanService:LoanServiceService )
  {
    this.model ={
      typeofloan:'',
      interestRate:null
    };
  }

  onSubmit()
  {
    this.loanService.isLoanAldreadyExists(this.model)
    .subscribe(exists =>{
      if(exists){
        // this.a = 1;
        alert(" Loan Already Exists");
        window.location.reload(); 
      }
      else{
        this.addLoanSubscription = this.loanService.addLoan(this.model)
        .subscribe({
          next:(response) =>{
              alert("Added Successfully");
              this.router.navigateByUrl('/home');
          },
        });
      }
    }
  )}
  ngOnDestroy(): void {
    this.addLoanSubscription?.unsubscribe();
  }
}
