import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute ,Router} from '@angular/router';
import { Subscription } from 'rxjs';
import { LoanServiceService } from '../../Services/loan-service.service';
import {  response } from 'express';
import { viewLoan } from '../../models/viewAll-loan.model';
import { UpdateLoan } from '../../models/update-loan.model';

@Component({
  selector: 'app-update-loan',
  templateUrl: './update-loan.component.html',
  styleUrl: './update-loan.component.css'
})
export class UpdateLoanComponent implements OnInit, OnDestroy{
  loanId: number |null=null;
  paramsSubscription?:Subscription;
  updateSubscription?:Subscription;
  loans?:viewLoan;
  constructor( private router:Router,
    private route:ActivatedRoute,
    private LoanService:LoanServiceService
   ){ }

  ngOnInit(): void {
    this.paramsSubscription= this.route.paramMap.subscribe({
      next: (params) =>
        {
          const Id = params.get('loanId');
          if(Id !=null)
            {
              this.loanId=parseInt(Id);
            }
          if(this.loanId)//not null
            {
              this.LoanService.getLoanByID(this.loanId)
              .subscribe({
                next:(response) => {
                    this.loans=response;
                }
              });
            }
        }
    });
  }

  OnFormSubmit():void{
    const loanUpdate:UpdateLoan = {
      typeofloan: this.loans?.typeofloan ?? '',
      interestRate:this.loans?.interestRate ?? 0
    };
    if(this.loanId)
      {
       this.updateSubscription= this.LoanService.UpdateLoanByID(this.loanId,loanUpdate)
        .subscribe({
          next:(response)=> {
            alert("Updated Successfully");
            this.router.navigateByUrl('/allLoan');
          }
        });
      }
   
  }
  ngOnDestroy(): void {
    this.paramsSubscription?.unsubscribe();
    this.updateSubscription?.unsubscribe();
  }
}
