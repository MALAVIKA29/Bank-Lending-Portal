﻿using BankLending_BAL.DTO;
using BankLending_BAL.Services;
using BankLending_DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;


namespace BankLending_BAL.Mapper
{
   public class BankLendingMapper : Profile
    {
        public BankLendingMapper()
        {
            CreateMap<LoanMasterDTO, LoanMaster>()

           .ForMember(a => a.typeofloan, l => l.MapFrom(c => c.typeofloan))
           .ForMember(a => a.interestRate, l => l.MapFrom(c => c.interestRate));


            CreateMap<LoanMaster, LoanMasterDTO>()
            .ForMember(a => a.loanId, l => l.MapFrom(c => c.loanId))
            .ForMember(a => a.typeofloan, l => l.MapFrom(c => c.typeofloan))
            .ForMember(a => a.interestRate, l => l.MapFrom(c => c.interestRate))
             .ForMember(a => a.dateOfCreation, l => l.MapFrom(c => c.dateOfCreation));

            CreateMap<LoanAppMaster, LoanAppMasterDTO>()
            .ForMember(a => a.loanAppId, l => l.MapFrom(c => c.loanAppId))
            .ForMember(a => a.loanId, l => l.MapFrom(c => c.loanId))
            .ForMember(a => a.loanAmount, l => l.MapFrom(c => c.loanAmount))
            .ForMember(a => a.noOfMonths, l => l.MapFrom(c => c.noOfMonths))
            .ForMember(a => a.rateOfInterest, l => l.MapFrom(c => c.rateOfInterest))
            .ForMember(a => a.applicationDate, l => l.MapFrom(c => c.applicationDate));


            CreateMap<LoanAppMasterDTO, LoanAppMaster>()
           .ForMember(a => a.loanAppId, l => l.MapFrom(c => c.loanAppId))
           .ForMember(a => a.loanId, l => l.MapFrom(c => c.loanId))
           .ForMember(a => a.loanAmount, l => l.MapFrom(c => c.loanAmount))
           .ForMember(a => a.noOfMonths, l => l.MapFrom(c => c.noOfMonths))
           .ForMember(a => a.rateOfInterest, l => l.MapFrom(c => c.rateOfInterest))
           .ForMember(a => a.applicationDate, l => l.MapFrom(c => c.applicationDate));

            CreateMap<LoanAppDetailMasterDTO, LoanAppDetailMaster>()
            .ForMember(a => a.Id, l => l.MapFrom(c => c.Id))
            .ForMember(a => a.loanAppId, l => l.MapFrom(c => c.loanAppId))
            .ForMember(a => a.monthNo, l => l.MapFrom(c => c.monthNo))
            .ForMember(a => a.installment, l => l.MapFrom(c => c.installment))
            .ForMember(a => a.interestRate, l => l.MapFrom(c => c.interestRate))
            .ForMember(a => a.prOutStandingEndOfmon, l => l.MapFrom(c => c.prOutStandingEndOfmon))
            .ForMember(a => a.pRepayment, l => l.MapFrom(c => c.pRepayment))
            .ForMember(a => a.prOutStandingEndOfmon, l => l.MapFrom(c => c.prOutStandingEndOfmon))
            .ForMember(a => a.lastDateofinstallPay, l => l.MapFrom(c => c.lastDateofinstallPay));

            CreateMap<LoanAppDetailMaster, LoanAppDetailMasterDTO>()
           //.ForMember(a => a.Id, l => l.MapFrom(c => c.Id))
           .ForMember(a => a.loanAppId, l => l.MapFrom(c => c.loanAppId))
           .ForMember(a => a.monthNo, l => l.MapFrom(c => c.monthNo))
           .ForMember(a => a.installment, l => l.MapFrom(c => c.installment))
           .ForMember(a => a.interestRate, l => l.MapFrom(c => c.interestRate))
           .ForMember(a => a.prOutStandingEndOfmon, l => l.MapFrom(c => c.prOutStandingEndOfmon))
           .ForMember(a => a.pRepayment, l => l.MapFrom(c => c.pRepayment))
           .ForMember(a => a.prOutStandingEndOfmon, l => l.MapFrom(c => c.prOutStandingEndOfmon))
           .ForMember(a => a.lastDateofinstallPay, l => l.MapFrom(c => c.lastDateofinstallPay));
        }
    }
}
