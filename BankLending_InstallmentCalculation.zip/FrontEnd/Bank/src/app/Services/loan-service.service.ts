import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';
import { environment } from '../../environments/environment';
import { loan } from '../models/Add-loan.model';
import { viewLoan } from '../models/viewAll-loan.model';
import { UpdateLoan } from '../models/update-loan.model';
import { ReducedPayment } from '../models/Reduced-Payment.model';



@Injectable({
  providedIn: 'root'
})
export class LoanServiceService {

  constructor(private http:HttpClient) { }
  
  isLoanAldreadyExists(newLoan : any) : Observable<boolean>
  {
    return this.http.get<any[]>(`${environment.apiBaseUrl}/api/BankLending`).pipe(
      map(el => {
         return el.some(loan => {
          return loan.typeofloan === newLoan.typeofloan && loan.interestRate === newLoan.interestRate;
         });
      })
    );
  }
  addLoan( model:loan): Observable<void>
  {
    return this.http.post<void>(`${environment.apiBaseUrl}/api/BankLending`,model);
  }
  getAllLoan():Observable<viewLoan[]>
  {
    return this.http.get<viewLoan[]>(`${environment.apiBaseUrl}/api/BankLending`);
  }
  getLoanByID(id:number):Observable<viewLoan>
  {
    return this.http.get<viewLoan>(`${environment.apiBaseUrl}/api/BankLending/${id}`);
  }
  UpdateLoanByID(id:number,loanUpdate:UpdateLoan):Observable<viewLoan>
  {
    return this.http.put<viewLoan>(`${environment.apiBaseUrl}/api/BankLending/${id}`,loanUpdate);
  }
  getReducedPayment(id:number):Observable<ReducedPayment[]>
  {
    return this.http.get<ReducedPayment[]>(`${environment.apiBaseUrl}/api/BankLending/GeneratePayment/${id}`);
  }
  calcEMI(id:number):Observable<number>
  {
    return this.http.get<number>(`${environment.apiBaseUrl}/api/BankLending/emi/${id}`);
  }
  generateReducedPayment(id:number):Observable<boolean>
  {
    return this.http.post<boolean>(`${environment.apiBaseUrl}/api/BankLending/id/${id}`,Boolean);
  }
  
}