import { Component, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { LoanServiceService } from '../../Services/loan-service.service';
import { ReducedPayment } from '../../models/Reduced-Payment.model';

@Component({
  selector: 'app-reduced-payment',
  templateUrl: './reduced-payment.component.html',
  styleUrl: './reduced-payment.component.css'
})
export class ReducedPaymentComponent implements OnDestroy {
  LoanId:number =null;
  loanSubscription?:Subscription;
  a:number=0;
  loans?:ReducedPayment[];
  isButtonVisible=true;
  visibleRows:ReducedPayment[];
  constructor( private router:Router,
    private route:ActivatedRoute,
    private LoanService:LoanServiceService
   ){ }
   onSubmit()
   {
    this.isButtonVisible=true;
    this.loanSubscription= this.LoanService.getReducedPayment(this.LoanId)
     .subscribe(
      (loan)=>{
        console.log(loan);
        this.loans=loan;
        this.visibleRows=this.loans.slice(0,10);
        if(this.loans.length !=0)
          {
            this.a=1;
          }
          else{
            this.a=2;
          }
     console.log(this.a);
       
      }
    );
   }
   showAllRows()
   {
    this.visibleRows=this.loans;
    this.isButtonVisible=false;
   }
   onChange()
   {
    this.a=0;
   }
   ngOnDestroy(): void {
      this.loanSubscription?.unsubscribe();
     }
  
}
