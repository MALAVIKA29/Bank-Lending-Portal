import { Component } from '@angular/core';
import { viewLoan } from '../../models/viewAll-loan.model';
import { LoanServiceService } from '../../Services/loan-service.service';

@Component({
  selector: 'app-edit-loan',
  templateUrl: './edit-loan.component.html',
  styleUrl: './edit-loan.component.css'
})
export class EditLoanComponent {
  Loans?: viewLoan[];
  constructor(private loanService:LoanServiceService)
  {
    
  }
  ngOnInit(): void {
    this.loanService.getAllLoan()
    .subscribe({
      next:(response)=> {
        this.Loans=response;
      }
    });
  }
  }

