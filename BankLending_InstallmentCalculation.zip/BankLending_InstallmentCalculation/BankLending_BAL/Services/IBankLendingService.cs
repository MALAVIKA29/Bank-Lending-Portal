﻿using BankLending_BAL.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLending_BAL.Services
{
    public interface IBankLendingService
    {
        public async Task<int?> AddLoanInformation(LoanMasterDTO loan) { return 0; }
        public async Task<object> GetLoanInformation(int loan_id) { return null; }
        public async Task<List<LoanMasterDTO>> GetLoanMasters() { return null; }
        public async Task<bool> UpdateLoanInformation(int id, LoanMasterDTO loan) { return false; }

        public async Task<int?> CalculateInstallment(int LoanApp_Id) { return null; }
        public async Task<bool> GetReducedPaymentInformation(int id) {  return false; }
        public async Task<List<LoanAppDetailMasterDTO>> ReducedPayemtList(int loanApp_id) { return null; }
    }
}