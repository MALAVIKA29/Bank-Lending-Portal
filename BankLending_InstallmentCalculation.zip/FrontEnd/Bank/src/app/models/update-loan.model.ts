export interface UpdateLoan{
    typeofloan :string;
    interestRate:number;
}