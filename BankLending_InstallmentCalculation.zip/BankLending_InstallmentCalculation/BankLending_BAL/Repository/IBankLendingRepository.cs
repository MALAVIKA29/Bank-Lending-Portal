﻿using BankLending_BAL.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLending_BAL.Repository
{
    public interface IBankLendingRepository
    {
        public async Task<int?> AddLoan(LoanMasterDTO loan) { return null; }
        public async Task<object> GetLoanById(int loan_id) { return null; }
        public async Task<List<LoanMasterDTO>> GetAllLoan() { return null; }
        public async Task<bool> UpdateLoan(int id, LoanMasterDTO loan) { return false; }
        public async Task<LoanAppMasterDTO> EMICalculation(int LoanApp_Id) {  return null; }
        public async Task<LoanAppMasterDTO> GetReducedPayment(int id) { return null; }
        public async Task<int?> AddGetReducedPayment (LoanAppDetailMasterDTO loanDetailDTO) { return null; }
        public async Task<List<LoanAppDetailMasterDTO>> GenerateRPayment(int loanApp_id) { return null; }
    }
}
