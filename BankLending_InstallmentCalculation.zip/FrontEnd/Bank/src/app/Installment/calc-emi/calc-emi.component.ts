import { Component, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { LoanServiceService } from '../../Services/loan-service.service';



@Component({
  selector: 'app-calc-emi',
  templateUrl: './calc-emi.component.html',
  styleUrl: './calc-emi.component.css'
})
export class CalcEmiComponent implements OnDestroy{
  LoanId:number =null;
  loanSubscription?:Subscription;
 

  emi:number=null;
  constructor( private router:Router,
    private route:ActivatedRoute,
    private LoanService:LoanServiceService
   ){ }
   a: number = 0;
   onSubmit()
   {
    this.loanSubscription= this.LoanService.calcEMI(this.LoanId)
     .subscribe(
      (loan)=>{
       this.emi=loan
        console.log(loan);
        this.a=1;
      },
      error =>{
        this.a=2;
      }
     
    );
   }
  // reload()
  // {
  //   window.location.reload();
   
  // }

  onChange(){
    this.a=0;
  }
   ngOnDestroy(): void {
      this.loanSubscription?.unsubscribe();
     }
  
}

