export interface loan{
    typeofloan:string;
    interestRate?:number;
}